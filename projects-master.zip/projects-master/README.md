# projects

This is to create single page application for telecom domain using Angularjs
