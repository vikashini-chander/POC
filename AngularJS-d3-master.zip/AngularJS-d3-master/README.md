This is a project built with SVG, AngularJS and D3.js. There are two graphs: Pie && bar. 

Pie Graph is an interactive graph:
1.The width/height is default to 800 px if the user does not set a value. 

2.The pie graph will be changed according the input value 

Bar Graph is built with Angularjs directive. All functions are accomplished with in Link. Data pass to directive through scope  
