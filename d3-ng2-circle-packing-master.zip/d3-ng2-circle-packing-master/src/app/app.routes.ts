export const appRoutes = [
  { path: '', redirectTo: '/', pathMatch: 'full' },
];
